import { createSlice } from "@reduxjs/toolkit";

export const productSlice = createSlice({
  name: "products",
  initialState: { items: [], allItems: [] },
  reducers: {
    setProduct: (state, action) => {
      state.items = action.payload;
      state.allItems = action.payload;
    },
    searchProduct: (state, action) => {
      const search = action.payload.toLowerCase();
      state.items = state.allItems.filter((item) =>
        item.description.toLowerCase().includes(search)
      );
    },
    resetSearch: (state) => {
      state.items = state.allItems;
    },
  },
});

export const cartSlice = createSlice({
  name: "cart",
  initialState: { items: [], totalPrice: 0, quantity:0},
  reducers: {
    addToCart: (state, action) => {
      const index = state.items.findIndex((item) => item.id === action.payload.id);

      if (index !== -1) {
        state.items[index].quantity += 1; 
      } else {
        state.items.push({ ...action.payload, quantity: 1 }); 
      }

      state.totalPrice += action.payload.price;
      state.quantity += 1
    },

    removeFromCart: (state, action) => {
      const index = state.items.findIndex((item) => item.id === action.payload);

      if (index !== -1) {
        state.items[index].quantity -= 1; 
        state.totalPrice -= state.items[index].price;
        if (state.items[index].quantity === 0) {
          state.items.splice(index, 1); 
        }
        state.quantity -= 1
      }
    },
    emptyCart: (state, action) => {
      state.items = state.items.filter((item) => item.id !== action.payload);
      state.totalPrice = state.items.reduce((acc, item) => acc + item.price * item.quantity, 0);
      state.quantity = state.items.reduce((acc, item) => acc + item.quantity, 0);
    },
  },
});



export const { setProduct, searchProduct, resetSearch } = productSlice.actions;
export const { addToCart, removeFromCart, emptyCart } = cartSlice.actions;

export const productReducer = productSlice.reducer;
export const cartReducer = cartSlice.reducer;
