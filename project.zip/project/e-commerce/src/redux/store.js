import { configureStore } from '@reduxjs/toolkit'
import { cartReducer, productReducer } from './counterSlice'


export const store = configureStore({
  reducer: {
    product: productReducer,
    cart: cartReducer,
  },
})