import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from "./components/Header";
import ProductItem from "./components/ProductItem"
import Cart from "./components/Cart"
import NotFound from "./components/NotFound"
import Nav from './components/Nav';
// import Loading from './components/Loading';
import ProductList from './components/ProductList';

function App() {
  return (
    <Router>
      <Nav/>
      <Routes>
        <Route path='/' element={<Header/>}/>
        <Route path='/productItem' element={<ProductItem/>}/>
        <Route path='/products' element = {<ProductList/>}/>
        <Route path='/cart' element={<Cart/>}/>
        <Route path='*' element={<NotFound/>}/>
      </Routes>
    </Router>
  )
}

export default App
