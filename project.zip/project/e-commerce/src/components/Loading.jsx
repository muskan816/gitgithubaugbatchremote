// import React,{Suspense} from 'react'
// const ProductList = React.lazy(()=> import("./components/ProductList"))

// const Loading = () => {
//   return (
//     <Suspense fallback = {<div>Loading...</div>}>
//         <ProductList/>
//     </Suspense>
//   )
// }

// export default Loading