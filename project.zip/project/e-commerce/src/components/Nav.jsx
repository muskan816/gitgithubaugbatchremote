import React, { useState } from "react";
import "../App.css";
import { NavLink } from "react-router-dom";
import { TiShoppingCart } from "react-icons/ti";
import { GiHamburgerMenu } from "react-icons/gi";
import { useSelector } from "react-redux";

const Nav = () => {
  const [isNavOpen, setIsNavOpen] = useState(false);
  const cart = useSelector((state) => state.cart); 

  return (
    <div className="nav-container bg-blue-950 mt-0.5">
      <ul className="flex flex-row justify-between items-center mb-0.5">
        <li className="ml-5 m-2">
          <img
            src="./shopping-cart-logo.png"
            alt="Shopping Cart"
            className="w-12 rounded-full"
          />
        </li>
        <div className="flex gap-12 text-blue-200 items-center">
          <button>
            <NavLink to="/" className="hover:text-blue-400 md:block hidden">
              Home
            </NavLink>
          </button>
          <button>
            <NavLink
              to="/products"
              className="hover:text-blue-400 md:block hidden"
            >
              Products
            </NavLink>
          </button>
          <button className="relative mr-9 hover:text-blue-400 md:block hidden">
            <NavLink to="/cart">
              <TiShoppingCart size={30} className="m-1" />
              {cart.quantity > 0 && ( 
                <span className="absolute top-0 right-0 text-xs w-5 h-5 bg-blue-600 text-white rounded-full flex justify-center items-center">
                  {cart.quantity}
                </span>
              )}
            </NavLink>
          </button>
          <button
            onClick={() => setIsNavOpen(!isNavOpen)}
            className="mr-9 hover:text-blue-400 md:hidden sm:block"
          >
            <GiHamburgerMenu size={25} />
          </button>
          {console.log(cart)}
        </div>
      </ul>
      {isNavOpen && (
        <div className="fixed top-0 left-0 w-full h-full bg-blue-900 text-blue-200 z-10">
          <button
            onClick={() => setIsNavOpen(false)}
            className="absolute top-4 right-4 text-white text-2xl"
          >
            X
          </button>
          <div className="flex flex-col justify-center items-center gap-7 h-full">
            <NavLink
              to="/"
              onClick={() => setIsNavOpen(false)}
              className="hover:text-blue-400 text-2xl"
            >
              Home
            </NavLink>
            <NavLink
              to="/products"
              onClick={() => setIsNavOpen(false)}
              className="hover:text-blue-400 text-2xl"
            >
              Products
            </NavLink>
            <NavLink
              to="/cart"
              onClick={() => setIsNavOpen(false)}
              className="hover:text-blue-400 relative"
            >
              <TiShoppingCart size={45} className="m-1" />
              {cart.quantity > 0 && ( 
                <span className="absolute top-0 right-0 text-xs w-5 left-3 bg-blue-600 text-white rounded-full flex justify-center">
                  {cart.quantity}
                </span>
              )}
            </NavLink>
          </div>
        </div>
      )}
    </div>
  );
};

export default Nav;
