import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { resetSearch, searchProduct, setProduct } from "../redux/counterSlice";
import ProductDetail from "./ProductDetail";

const ProductList = () => {
  const [input, setInput] = useState(""); // State for the search input field
  const [filteredItems, setFilteredItems] = useState([]); // State for filtered products
  const [selectedProduct, setSelectedProduct] = useState(null); // State for selected product details
  const dispatch = useDispatch(); // Redux dispatch function to update store
  const products = useSelector((state) => state.product); // Access the products from Redux store

  // Fetch products when the component mounts, only if no products are available in the store
  useEffect(() => {
    if (!products.items || products.items.length === 0) {
      fetchData(); // Fetch products from the API
    }
  }, [products.items]);

  // Function to fetch product data from the API
  const fetchData = async () => {
    try {
      const res = await fetch("https://fakestoreapi.com/products");
      if (!res.ok) throw new Error("Failed to fetch products");
      const result = await res.json();
      dispatch(setProduct(result)); // Dispatch action to store the fetched data in Redux
    } catch (error) {
      console.error("Error fetching data:", error); // Log any errors during the fetch process
    }
  };

  // Function to handle search input submission
  const searchHandler = (e) => {
    e.preventDefault(); // Prevent the default form submission behavior
    if (input.trim() !== "") {
      dispatch(searchProduct(input)); // Dispatch search action with input value
    } else {
      dispatch(resetSearch()); // Reset the search if input is empty
    }
    setInput(""); // Clear the input field after submitting
  };

  // Function to handle category selection and filter products based on category
  const handleCategory = (category) => {
    if (category === "All") {
      setFilteredItems([]); // Reset filtered items if "All" is selected
    } else {
      // Filter products by selected category
      const filtered = products.items.filter((item) => item.category === category);
      setFilteredItems(filtered); // Update filteredItems state
    }
  };

  // Function to handle product click, setting the selected product for detailed view
  const handleProductClick = (product) => {
    setSelectedProduct(product); // Set selected product
  };

  return selectedProduct ? (
    // If a product is selected, show the ProductDetail component
    <ProductDetail product={selectedProduct} onBack={() => setSelectedProduct(null)} />
  ) : (
    // Render the product list if no product is selected
    <div className="flex flex-col md:flex-row bg-gray-50">
      {/* Categories Section */}
      <div className="w-full md:w-1/4 bg-gray-100 p-4 text-center">
        <div className="bg-blue-900 text-white rounded-lg p-4">
          <h2 className="text-lg font-bold underline mb-4">Categories</h2>
          <button
            className="block hover:text-blue-400 py-2"
            onClick={() => handleCategory("All")} // Handle "All" category click
          >
            All
          </button>
          {products.items?.length > 0 ? (
            // If there are products, display categories dynamically
            [...new Set(products.items.map((item) => item.category))].map(
              (category, index) => (
                <button
                  key={index}
                  className="block text-left hover:text-blue-400 py-2"
                  onClick={() => handleCategory(category)} // Filter products by category
                >
                  {category}
                </button>
              )
            )
          ) : (
            <p className="text-sm text-gray-400">No categories found</p> // Message when no categories are available
          )}
        </div>
      </div>

      {/* Products Section */}
      <div className="w-full md:w-3/4 p-4">
        {/* Search Bar */}
        <form onSubmit={searchHandler} className="mb-6">
          <div className="flex items-center">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)} // Update input value on change
              placeholder="Search here..."
              className="w-full p-3 rounded-l-lg border border-blue-300"
            />
            <button
              type="submit"
              className="bg-blue-900 text-white px-6 py-3 rounded-r-lg hover:bg-blue-800"
            >
              Search
            </button>
          </div>
        </form>

        {/* Displaying Products */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {filteredItems.length > 0
            ? filteredItems.map((item) => (
                <div
                  key={item.id}
                  className="border border-blue-300 rounded-lg overflow-hidden shadow-sm bg-white cursor-pointer"
                  onClick={() => handleProductClick(item)} // Handle product click
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    className="h-40 w-full object-contain bg-white"
                  />
                  <div className="p-4 text-center">
                    <p className="text-lg font-bold text-gray-800">${item.price}</p>
                    <p className="text-sm text-gray-500">{item.category}</p>
                  </div>
                </div>
              ))
            : products.items.map((item) => (
                <div
                  key={item.id}
                  className="border border-blue-300 rounded-lg overflow-hidden shadow-sm bg-white cursor-pointer"
                  onClick={() => handleProductClick(item)} // Handle product click
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    className="h-40 w-full object-contain bg-white"
                  />
                  <div className="p-4 text-center">
                    <p className="text-lg font-bold text-gray-800">${item.price}</p>
                    <p className="text-sm text-gray-500">{item.category}</p>
                  </div>
                </div>
              ))}
        </div>
      </div>
    </div>
  );
};

export default ProductList;
