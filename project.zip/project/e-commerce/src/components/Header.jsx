import ProductList from "./ProductList";

const Header = () => {
  return (
    <div className="bg-blue-100 min-h-screen">
      {/* Banner */}
      <div className="relative">
        <img
          src="https://i.pinimg.com/736x/78/b9/0f/78b90fd6402e73695e318002b1304a11.jpg"
          className="h-[50vh] w-full object-cover"
          alt="Banner"
        />
        <h1
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 
          text-white text-4xl font-bold drop-shadow-2xl 
          [text-shadow:_2px_2px_5px_rgba(0,0,255,0.8)]"
        >
          Welcome to Our Store
        </h1>
      </div>
      <ProductList />
    </div>
  );
};

export default Header;
