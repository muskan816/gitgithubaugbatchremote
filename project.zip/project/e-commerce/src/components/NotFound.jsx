import React from 'react'

const NotFound = () => {
  return (
    <div>
      <div className='flex items-center flex-col'>
      <h2 className='text-2xl font-bold my-16'>Something Wrong Here!</h2>
      <img src='https://lh5.ggpht.com/_9F9_RUESS2E/SpV5Yi8Vv5I/AAAAAAAAA4E/W9-J8eMLokM/s800/50-Cool-and-Creative-404-Error-Pages-25.jpg' alt='Page Not Found'
      />
      </div>
    </div>
  )
}

export default NotFound