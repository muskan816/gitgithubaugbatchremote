import React from "react";
import ProductItem from "./ProductItem"
import ProductList from "./ProductList";

const ProductDetail = ({ product, onBack }) => {
  return (
    <div className="p-4">
      <button
        onClick={onBack}
        className="bg-blue-900 text-white px-4 py-2 rounded-lg -mb-8 ml-2 cursor-pointer"
      >
        Back
      </button>
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-4">
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-52 object-contain mb-2"
        />
        <h2 className="text-2xl font-bold text-gray-800 mb-1">
          {product.title}
        </h2>
        <p className="text-gray-600 mb-1">{product.description}</p>
        <p className="text-lg font-bold text-gray-800">${product.price}</p>
        <p className="text-sm text-gray-500 mt-1">{product.category}</p>
      </div>
      <ProductItem product={product}/>
      <br/>
      <ProductList/>
    </div>
  );
};

export default ProductDetail;
