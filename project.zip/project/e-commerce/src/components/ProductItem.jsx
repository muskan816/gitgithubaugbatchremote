import React, { useState } from "react";
import { addToCart, removeFromCart } from "../redux/counterSlice";
import { useDispatch, useSelector } from "react-redux";

const ProductItem = ({ product }) => {
  const dispatch = useDispatch(); // Redux dispatch function to trigger actions
  const cartItems = useSelector((state) => state.cart.items); // Get cart items from Redux state
  const isInCart = cartItems.some((item) => item.id === product.id); // Check if the current product is in the cart
  const [openAddedCart, setOpenAddedCart] = useState(isInCart); // State to manage the UI for add/remove cart actions

  // Function to handle adding the product to the cart
  const handleAddToCart = () => {
    dispatch(addToCart(product)); // Dispatch action to add the product to the cart
    setOpenAddedCart(true); // Change the button state to show 'Added To Cart'
  };

  // Function to handle removing the product from the cart
  const handleRemoveFromCart = () => {
    dispatch(removeFromCart(product.id)); // Dispatch action to remove the product by its ID
    setOpenAddedCart(false); // Change the button state to show 'Add To Cart'
  };

  return (
    <div>
      {/* If the product is in the cart, show the 'Added To Cart' button and remove button */}
      {openAddedCart ? (
        <div className="flex justify-center mt-4 -mb-2">
          <button className="w-2/4 md:w-[350px] cursor-pointer p-4 bg-blue-900 text-white rounded-2xl">
            Added To Cart
          </button>
          <button
            onClick={handleRemoveFromCart} // Remove the product from cart when clicked
            className="w-1/4 md:w-[200px] cursor-pointer p-4 bg-red-500 text-white rounded-2xl ml-1"
          >
            Remove
          </button>
        </div>
      ) : (
        // If the product is not in the cart, show the 'Add To Cart' button
        <div className="flex justify-center mt-4 -mb-2">
          <button
            onClick={handleAddToCart} // Add the product to cart when clicked
            className="w-2/4 cursor-pointer p-4 bg-blue-900 text-white rounded-2xl"
          >
            Add To Cart
          </button>
        </div>
      )}
    </div>
  );
};

export default ProductItem;
