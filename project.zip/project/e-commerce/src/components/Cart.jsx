import React, { useState } from "react";
import "../App.css";
import { NavLink } from "react-router-dom";
import { TiShoppingCart } from "react-icons/ti"; // Import cart icon
import { GiHamburgerMenu } from "react-icons/gi"; // Import hamburger menu icon for mobile view
import { useSelector } from "react-redux"; // Import useSelector to access the Redux store

const Nav = () => {
  const [isNavOpen, setIsNavOpen] = useState(false); // State to manage the mobile navigation menu (open/close)
  const cart = useSelector((state) => state.cart); // Access the cart data from Redux store

  return (
    <div className="nav-container bg-blue-950 mt-0.5">
      {/* Main navigation bar */}
      <ul className="flex flex-row justify-between items-center mb-0.5">
        {/* Logo Section */}
        <li className="ml-5 m-2">
          <img
            src="./shopping-cart-logo.png" // Logo image
            alt="Shopping Cart"
            className="w-12 rounded-full" // Style the logo
          />
        </li>

        {/* Navigation Links */}
        <div className="flex gap-12 text-blue-200 items-center">
          {/* Home Link */}
          <button>
            <NavLink to="/" className="hover:text-blue-400 md:block hidden">
              Home
            </NavLink>
          </button>

          {/* Products Link */}
          <button>
            <NavLink
              to="/products"
              className="hover:text-blue-400 md:block sm:hidden"
            >
              Products
            </NavLink>
          </button>

          {/* Cart Section */}
          <button className="relative mr-9 hover:text-blue-400 md:block sm:hidden">
            <NavLink to="/cart">
              <TiShoppingCart size={30} className="m-1" /> {/* Cart Icon */}
              {/* Show cart quantity if greater than 0 */}
              {cart.quantity > 0 && (
                <span className="absolute top-0 right-0 text-xs w-5 h-5 bg-blue-600 text-white rounded-full flex justify-center items-center">
                  {cart.quantity}
                </span>
              )}
            </NavLink>
          </button>

          {/* Hamburger Menu for Mobile View */}
          <button
            onClick={() => setIsNavOpen(!isNavOpen)} // Toggle mobile navigation visibility
            className="mr-9 hover:text-blue-400 md:hidden sm:block"
          >
            <GiHamburgerMenu size={25} /> {/* Hamburger menu icon */}
          </button>
          
          {/* Debugging cart content (optional log) */}
          {console.log(cart)}
        </div>
      </ul>

      {/* Mobile Navigation Menu (shows when isNavOpen is true) */}
      {isNavOpen && (
        <div className="fixed top-0 left-0 w-full h-full bg-blue-900 text-blue-200 z-10">
          {/* Close Button for Mobile Navigation */}
          <button
            onClick={() => setIsNavOpen(false)} // Close the mobile navigation when clicked
            className="absolute top-4 right-4 text-white text-2xl"
          >
            X
          </button>

          {/* Links inside the mobile navigation */}
          <div className="flex flex-col justify-center items-center gap-7 h-full">
            <NavLink
              to="/"
              onClick={() => setIsNavOpen(false)} // Close navigation when link is clicked
              className="hover:text-blue-400 text-2xl"
            >
              Home
            </NavLink>
            <NavLink
              to="/products"
              onClick={() => setIsNavOpen(false)} // Close navigation when link is clicked
              className="hover:text-blue-400 text-2xl"
            >
              Products
            </NavLink>
            <NavLink
              to="/cart"
              onClick={() => setIsNavOpen(false)} // Close navigation when link is clicked
              className="hover:text-blue-400 relative"
            >
              <TiShoppingCart size={45} className="m-1" /> {/* Cart Icon */}
              {/* Show cart quantity if greater than 0 */}
              {cart.quantity > 0 && (
                <span className="absolute top-0 right-0 text-xs w-5 left-3 bg-blue-600 text-white rounded-full flex justify-center">
                  {cart.quantity}
                </span>
              )}
            </NavLink>
          </div>
        </div>
      )}
    </div>
  );
};

export default Nav;
