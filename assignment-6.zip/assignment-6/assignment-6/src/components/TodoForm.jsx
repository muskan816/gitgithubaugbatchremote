import { useState } from 'react';

function TodoForm({ handleAddTask }) {
  const [task, setTask] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    handleAddTask(task);
    setTask('');
  };

  return (
    <div className="input-bar">
      <form className="input" onSubmit={handleSubmit}>
        <input
          type="text"
          className="inputText"
          value={task}
          placeholder="Add a task"
          onChange={(e) => setTask(e.target.value)}
        />
        <button className="task-btn" type="submit">
          Add
        </button>
      </form>
    </div>
  );
}

export default TodoForm;
