import { useState } from 'react';
import TodoForm from './TodoForm';
import TodoItem from './TodoItem';
import './ToDo.css';

export const ToDoList = () => {
  const [tasks, setTasks] = useState([]);

  const handleAddTask = (taskText) => {
    if (!taskText.trim()) return;
    const newTask = {
      id: Date.now(),
      text: taskText,
      completed: false,
      isEditing: false,
    };
    setTasks([...tasks, newTask]);
  };

  const handleCompletedTask = (task) => {
    setTasks(
      tasks.map((t) =>
        t.id === task.id ? { ...t, completed: !t.completed } : t
      )
    );
  };

  const handleDeleteTask = (task) => {
    setTasks(tasks.filter((t) => t.id !== task.id));
  };

  const handleEditMode = (taskId) => {
    setTasks(
      tasks.map((t) =>
        t.id === taskId ? { ...t, isEditing: !t.isEditing } : t
      )
    );
  };

  const handleSaveTask = (taskId, newText) => {
    setTasks(
      tasks.map((t) =>
        t.id === taskId ? { ...t, text: newText, isEditing: false } : t
      )
    );
  };

  return (
    <div>
      <TodoForm handleAddTask={handleAddTask} />
      <div className="list">
        {tasks.map((task) => (
          <TodoItem
            key={task.id}
            currTask={task}
            handleCompletedTask={() => handleCompletedTask(task)}
            handleDeleteTask={() => handleDeleteTask(task)}
            handleEditMode={() => handleEditMode(task.id)}
            handleSaveTask={(newText) => handleSaveTask(task.id, newText)}
          />
        ))}
      </div>
    </div>
  );
};

export default ToDoList;
