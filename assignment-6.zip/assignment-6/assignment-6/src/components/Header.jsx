import './ToDo.css';

function Header() {
  return <header className="header">To-Do List</header>;
}

export default Header;
