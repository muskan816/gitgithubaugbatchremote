import { useState } from 'react';
import { FaCircleCheck } from 'react-icons/fa6';
import { RxCrossCircled } from 'react-icons/rx';
import { TiDelete } from 'react-icons/ti';
import { RiEditCircleFill } from 'react-icons/ri';
import './ToDo.css';

function TodoItem({
  currTask,
  handleCompletedTask,
  handleDeleteTask,
  handleEditMode,
  handleSaveTask,
}) {
  const [editText, setEditText] = useState(currTask.text);

  return (
    <div className="todo-item">
      {currTask.isEditing ? (
        <div>
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            className="edit-input"
          />
          <button onClick={() => handleSaveTask(editText)}>
            <FaCircleCheck />
          </button>
          <button onClick={handleEditMode}>
            <RxCrossCircled />
          </button>
        </div>
      ) : (
        <div className="todo-content">
          <p
            style={{
              textDecoration: currTask.completed ? 'line-through' : 'none',
            }}
          >
            {currTask.text}
          </p>
          <div className="list-btn">
            <button onClick={handleCompletedTask}>
              <FaCircleCheck />
            </button>
            <button onClick={handleDeleteTask}>
              <TiDelete />
            </button>
            <button onClick={handleEditMode}>
              <RiEditCircleFill />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default TodoItem;
