import './App.css';
import ToDoList from './components/ToDoList';
import Header from './components/Header';

export const App = () => {
  return (
    <div className="App">
      <Header />
      <ToDoList />
    </div>
  );
};

export default App;
