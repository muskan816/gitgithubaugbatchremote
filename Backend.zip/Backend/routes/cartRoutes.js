import express from "express";
import Cart from "../models/Cart.js";
import { authMiddleware } from "../middleware/auth.js";

const router = express.Router();

// Add to cart
router.post("/", authMiddleware, async (req, res) => {
  try {
    const { productId, quantity } = req.body;
    let cart = await Cart.findOne({ user: req.user.id });
    if (!cart) cart = new Cart({ user: req.user.id, items: [] });

    // Generate a JWT token for the logged-in user

    const itemIndex = cart.items.findIndex(
      (item) => item.product.toString() === productId
    );
    if (itemIndex > -1) {
      // Generate a JWT token for the logged-in user

      cart.items[itemIndex].quantity += quantity;
    } else {
      // Generate a JWT token for the logged-in user

      cart.items.push({ product: productId, quantity });
    }

    await cart.save();
    res.json({ message: "Cart updated", cart });
  } catch (error) {
    res.status(500).json({ message: "Error adding to cart" });
  }
});

// Update cart item quantity
router.put("/:productId", authMiddleware, async (req, res) => {
  try {
    const { quantity } = req.body;
    const cart = await Cart.findOne({ user: req.user.id });

    // Find the item in the cart and update its quantity

    const item = cart.items.find(
      (item) => item.product.toString() === req.params.productId
    );
    if (item) item.quantity = quantity;

    await cart.save();
    res.json({ message: "Cart updated", cart });
  } catch (error) {
    res.status(500).json({ message: "Error updating cart" });
  }
});

// Remove an item from the cart

router.delete("/:productId", authMiddleware, async (req, res) => {
  try {
    const { productId } = req.params;
    const userId = req.user.id;

    // Find the cart for the user

    let cart = await Cart.findOne({ user: userId });
    if (!cart) return res.status(404).json({ message: "Cart not found" });

    // Filter out the item to be removed

    cart.items = cart.items.filter(
      (item) => item.product.toString() !== productId
    );
    await cart.save();

    res.json({ message: "Item removed from cart", cart });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error removing item", error: error.message });
  }
});

// Get the user's cart

router.get("/", authMiddleware, async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.user.id }).populate(
      "items.productId"
    );
    if (!cart) return res.json({ message: "Cart is empty" });
    res.json(cart);
  } catch (error) {
    res.status(500).json({ message: "Error fetching cart" });
  }
});

// Remove an item from the cart (duplicate route, consider removing one)

router.delete("/:productId", authMiddleware, async (req, res) => {
  try {
    const userId = req.user.id;
    const { productId } = req.params;

    // Find the cart for the user

    const cart = await Cart.findOne({ userId });
    if (!cart) return res.status(404).json({ message: "Cart not found" });

    // Filter out the item to be removed

    cart.items = cart.items.filter(
      (item) => item.productId.toString() !== productId
    );
    await cart.save();

    res.json({ message: "Product removed from cart" });
  } catch (error) {
    res.status(500).json({ message: "Error removing from cart" });
  }
});

export default router;
