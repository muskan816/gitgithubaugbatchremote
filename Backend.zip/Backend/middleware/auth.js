import jwt from "jsonwebtoken";

// Middleware to authenticate the user using JWT
export const authMiddleware = (req, res, next) => {
  // Extract the token from the Authorization header
  const token = req.header("Authorization")?.split(" ")[1];

  // If no token is provided, return a 401 Unauthorized response
  if (!token)
    return res
      .status(401)
      .json({ message: "Access denied. No token provided." });

  try {
    // Verify the token using the secret key from environment variables
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    // If token verification fails, return a 401 Unauthorized response
    res.status(401).json({ message: "Invalid token" });
  }
};
