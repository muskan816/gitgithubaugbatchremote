import mongoose from "mongoose";
// Define the schema for the Product model

const ProductSchema = new mongoose.Schema(
  {
    name: { type: String, required: true }, //name
    price: { type: Number, required: true }, //price
    description: { type: String }, //description
    stock: { type: Number, required: true, min: 0 }, //stock quantity
  },
  { timestamps: true }
);

export default mongoose.model("Product", ProductSchema);
