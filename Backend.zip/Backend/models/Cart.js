import mongoose from "mongoose";
// If token verification fails, return a 401 Unauthorized response

const CartSchema = new mongoose.Schema(
  {
    // Reference to the User model

    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    items: [
      {
        // Reference to the Product model

        product: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Product",
          required: true,
        },
        // Quantity of the product in the cart

        quantity: { type: Number, required: true, min: 1 },
      },
    ],
  },
  { timestamps: true }
);

export default mongoose.model("Cart", CartSchema);
